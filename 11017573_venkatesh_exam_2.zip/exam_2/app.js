 const express = require('express')
const axios = require('axios')
const config = require('./config.json')

const server = express();



const getRealTimeData = async(flightcode) =>{
    https://www.flightradar24.com/data/airports/lcy/routes"}

   var getFilePath = config.serverAPI + 

}












server.get('flight data',async (req,res) =>{
    var myParams = req,params;
});

server.listen(3000, ()=>{
    console.log('Flight gateway has started....')
});
 {
    "serverAPI" :
    "accesskey" :
}